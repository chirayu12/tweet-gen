package utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Logger {
	public enum InitiatorType {
		DATA_GENERATOR,
		DATA_SERVER,
		WORKER,
		USER_CLIENT,
		DEFAULT
	}
	
	public enum LogType {
		INFO,
		ERROR
	}
	
	private InitiatorType Initiator = InitiatorType.DEFAULT;
	
	public Logger(InitiatorType type) {
		Initiator = type;
	}
	
	private void log(String message, LogType type) {
		Date date = Calendar.getInstance().getTime();  
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
        String dateString = dateFormat.format(date);
		System.out.println(type + " LOG - " + dateString + " - " + Initiator + ":" + message);
	}
	
	public void info(String message) {
		log(message, LogType.INFO);
	}
	
	public void error(String message) {
		log(message, LogType.ERROR);
	}
	
}
