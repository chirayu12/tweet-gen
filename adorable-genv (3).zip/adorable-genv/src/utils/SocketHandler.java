package utils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

public class SocketHandler {
	Socket Connection;
    final String MessageEndMarker = "#MESSAGEENDMARKER#";
    final String AcknowledgementMessage = "#ACKNOWLEDGED#";

    public SocketHandler(Socket connection) {
        Connection = connection;
    }

    public SocketHandler(){

    }
    
    public Socket getConnection() {
    	return Connection;
    }
    
    public void closeConnection() throws IOException {
    	Connection.close();
    }

    public void writeMessages(String[] messages) {
        try {
        	if(Connection.isClosed()) {
	        	return;
	        }
            OutputStream connectionOutputStream = Connection.getOutputStream();
            DataOutputStream connectionDataOutputStream = new DataOutputStream(connectionOutputStream);
            String message = "";
            for (int i = 0; i < messages.length; i++) {
                message += messages[i] + "\n";
                // connectionDataOutputStream.writeBytes(messages[i]);
                // connectionDataOutputStream.writeBytes("\n");
            }
            // System.out.println("LOG: writing " + message);
            connectionDataOutputStream.writeBytes(message);
            // connectionDataOutputStream.close();
            // connectionOutputStream.close();
        } catch (IOException exception) {
            System.out.println("There was a problem writing to the output stream: " + exception.getMessage());
        }
    }

    public void writeMessage(String message) {
        writeMessages(new String[] { message });
    }
    
    public void sendAcknowledgement() {
        writeMessage(AcknowledgementMessage);
    }
    
    public void sendWelcome(String assignedId) {
        writeMessage("WELCOME#" + assignedId);
    }

    void endMessage(){
        writeMessage(MessageEndMarker);
    }

    String read(boolean singleLine) {
        String lines = null;
		try {
	        if(Connection.isClosed()) {
	        	return lines;
	        }
            InputStream connectionInputStream = Connection.getInputStream();
            InputStreamReader connectionInputStreamReader = new InputStreamReader(connectionInputStream);
            BufferedReader connectionBufferedReader = new BufferedReader(connectionInputStreamReader);
            String line;
            // Read across multiple lines only if it isn't a single line read and until null or the end of message marker is reached
            do {
                // System.out.print("Reading: ");
                line = new String(connectionBufferedReader.readLine());
                // System.out.print(line + "\n");
                // Make lines an empty string if it is currently null, so we don't get null prepended
                lines = lines == null ? "" : lines;
                // Don't append the line if it is the end of message marker
                if(!line.equals(MessageEndMarker)) {
                	// Append line if lines is empty, otherwise append newline first before line
                    lines += !lines.equals("") ? "\n" + line : line;
                }
            } while (line != null && !line.equals(MessageEndMarker) && !singleLine);
            // connectionBufferedReader.close();
            // connectionInputStreamReader.close();
            // connectionInputStream.close();
        } catch (IOException exception) {
            System.out.println("There was a problem reading the input stream: " + exception.getMessage());
        }
        return lines;
    }

    public String readLine() {
        return read(true);
    }

    public String readLines() {
        return read(false);
    }
}
