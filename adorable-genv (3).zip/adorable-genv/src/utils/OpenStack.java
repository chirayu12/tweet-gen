package utils;


public class OpenStack {
	
	public OpenStack() {
		
	}

}
