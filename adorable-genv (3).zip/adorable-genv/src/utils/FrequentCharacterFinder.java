package utils;

import java.util.HashMap;
import java.util.Map;

public class FrequentCharacterFinder {
	static String[] Alphabets = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z".split(",");
	public static char Find(String theString) {
		String cleanString = theString.replaceAll("[^a-zA-Z]", "").toLowerCase();
		// Defaults to 0 if the string is empty
		String mostFrequentChar = "0";
		Integer mostFrequentCount = 0;
		HashMap<String, Integer> characterCounts = new HashMap<String, Integer>();
		for(String alphabet : Alphabets) {
			characterCounts.put(alphabet, 0);
		}
		
		for(char character : cleanString.toCharArray()) {
			String stringKey = String.valueOf(character);
			if(characterCounts.containsKey(stringKey)) {
				int currentCount = characterCounts.get(stringKey);
				currentCount++;
				characterCounts.put(stringKey, currentCount);
			}
		}
		
		for(Map.Entry<String, Integer> entry : characterCounts.entrySet()) {
			if(entry.getValue() > mostFrequentCount) {
				mostFrequentCount = entry.getValue();
				mostFrequentChar = entry.getKey();
			}
		}
		return mostFrequentChar.charAt(0);
	}
}
