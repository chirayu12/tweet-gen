package utils;

import java.util.Scanner;

public class UserInput {
	public static String acceptLine(){
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }
	public static String accept(){
        Scanner scanner = new Scanner(System.in);
        return scanner.next();
    }
}
