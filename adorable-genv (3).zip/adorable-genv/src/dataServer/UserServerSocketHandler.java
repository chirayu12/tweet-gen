package dataServer;

import java.io.IOException;
import java.net.Socket;
import java.time.Clock;

import models.UserClientRequest;
import models.UserClientRequest.RequestType;
import models.UserClientResponse;
import models.UserServerQueryResponse;
import utils.Logger;
import utils.SocketHandler;
import utils.Logger.InitiatorType;
import utils.Serializer;

public class UserServerSocketHandler extends SocketHandler implements Runnable {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);
	private WorkerManager WorkerManager;
	private int ConnectionCount;
	private String UserPassword;
	public UserServerSocketHandler(Socket connection, WorkerManager workerManager, int connectionCount) {
        super(connection);
        WorkerManager = workerManager;
        ConnectionCount = connectionCount;
    }
	@Override
	public void run() {
		// New User, Register
		register();
	}
	
	public String generateId() {
		return UserPassword + "R" + Clock.systemUTC().instant();
	}
	
	public void register() {
		String userPassword = ConnectionCount + "_" + Clock.systemUTC().instant();
		UserPassword = userPassword;
		sendWelcome(UserPassword);
		waitForNewQueries();
	}
	
	public void waitForNewQueries() {
		String requestString = readLine();
		try {
			UserClientRequest request = Serializer.fromString(requestString);
			UserClientResponse response = new UserClientResponse(request.Type);
			String generatedId = generateId();
			logger.info("New request from user - " + request.Type);
			if(request.Type == RequestType.QUERY) {
				response.RequestId = generatedId;
				request.Query.RequestId = generatedId;
				WorkerManager.submitQuery(request.Query);
			} else if(request.Type == RequestType.QUERY_STATUS_CHECK) {
				UserServerQueryResponse queryResponse = WorkerManager.getRequest(request.RequestId);
				response.QueryResponse = queryResponse;
			} else if(request.Type == RequestType.QUERY_CANCELLATION) {
				WorkerManager.cancelRequest(request.RequestId);
			} else if(request.Type == RequestType.WORKER_HEALTH_CHECK) {
				// 
			}
			String responseString = Serializer.toString(response);
			writeMessage(responseString);
		} catch (ClassNotFoundException | IOException exception) {
			// TODO Auto-generated catch block
			logger.error("Cannot deserialize user request: " + exception.getMessage());
		}
		waitForNewQueries();
	}
}
