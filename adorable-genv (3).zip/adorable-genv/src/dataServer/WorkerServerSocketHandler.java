package dataServer;

import java.io.IOException;
import java.net.Socket;
import java.time.Clock;

import models.IWorkerServerEventListener;
import models.WorkerServerRequest;
import utils.Logger;
import utils.SocketHandler;
import utils.Logger.InitiatorType;
import utils.Serializer;

public class WorkerServerSocketHandler extends SocketHandler implements Runnable {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);
	IWorkerServerEventListener Listener;
	int ConnectionCount;
	private WorkerManager WorkerManager;
	public WorkerServerSocketHandler(Socket connection, WorkerManager workerManager, IWorkerServerEventListener listener, int connectionCount) {
        super(connection);
        WorkerManager = workerManager;
        Listener = listener;
        ConnectionCount = connectionCount;
    }

	@Override
	public void run() {
		// New worker connection, register
		register();	
	}
	
	private void register() {
		String registrationString = readLine();
		// Check if it is a new worker or an existing worker trying a reconnection
		// New Workers: NEWCONNECTION#
		// Existing Workers: EXISTINGCONNECTION#AssignedWorkerID
		String[] registrationData = registrationString.split("#");
		logger.info(registrationData[0]);
		if(registrationData[0].equals("NEWCONNECTION")) {
			logger.info("New Worker Connection");
			// Create WorkerID 
			String workerId = ConnectionCount + "_" + Clock.systemUTC().instant();
			// Emit the new worker connection event
			if (Listener != null) Listener.onNewWorkerConnection(workerId, this);
			setupListeningHandler();
		} else if(registrationData[0].equals("EXISTINGCONNECTION")) {
			String workerId = registrationData[1];
			logger.info("Existing Worker Reconnection #" + workerId);
			if (Listener != null) Listener.onExistingWorkerReconnection(workerId, this);
		} else {
			// Invalid registration message, close the connection
			logger.error("Closing connection due to invalid registration string" + registrationString);
			try {
				closeConnection();
			} catch (IOException exception) {
				logger.error(exception.getMessage());
			}
		}
	}
	
	public void setupListeningHandler() {
		// Start thread for listening to messages
        WorkerServerSocketMessageListener workerServerSocketListeningHandler = new WorkerServerSocketMessageListener(this, WorkerManager);
        Thread handlerListeningThread = new Thread(workerServerSocketListeningHandler);
        handlerListeningThread.start();
	}
	
	public void waitForAcknowledgment() {
		String acknowledgment = readLine();
		if(acknowledgment.equals("#ACKNOWLEDGED#")) {
			logger.info("Worker Acknowledged" );
			return;
		}
	}
	
	public void sendRequest(WorkerServerRequest request) {
		try {
			String requestString = Serializer.toString(request);
			writeMessage(requestString);
		} catch (IOException exception) {
			logger.error(exception.getMessage());
		}
	}

}
