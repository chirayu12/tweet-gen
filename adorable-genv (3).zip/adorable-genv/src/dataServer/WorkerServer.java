package dataServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.Clock;

import models.IWorkerServerEventListener;
import utils.Logger;
import utils.Logger.InitiatorType;

public class WorkerServer implements Runnable {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);
	public WorkerManager WorkerManager;
	public WorkerServer(WorkerManager workerManager) {
		WorkerManager = workerManager;
	}
	
	private IWorkerServerEventListener Listener;
	public void setWorkerServerEventListener(IWorkerServerEventListener listener) {
		Listener = listener;
	}

	@Override
	public void run() {
		int port = 1112;
		
		// Start a server listening on the port
        ServerSocket server;
		try {
			server = new ServerSocket(port);
			logger.info("Starting worker server on: " + port);
	        int connectionCount = 0;
	        while (true) {
	            connectionCount++;
	            Socket socketConnection;
				socketConnection = server.accept();
				logger.info("New worker, worker count: " + connectionCount);
				
				// Start thread for sending requests
				WorkerServerSocketHandler workerServerSocketHandler = new WorkerServerSocketHandler(socketConnection, WorkerManager, Listener, connectionCount);
	            Thread handlerThread = new Thread(workerServerSocketHandler);
	            handlerThread.start();
	            
	        }
	        // server.close();
		} catch (IOException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		}
		
	}
}
