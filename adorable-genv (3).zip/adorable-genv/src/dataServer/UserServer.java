package dataServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import utils.Logger;
import utils.Logger.InitiatorType;

public class UserServer implements Runnable {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);
	WorkerManager WorkerManager;
	public UserServer(WorkerManager workerManager) {
		WorkerManager = workerManager;
	}

	@Override
	public void run() {
		int port = 1113;
		
		// Start a server listening on the port
        ServerSocket server;
		try {
			server = new ServerSocket(port);
			logger.info("Starting user server on: " + port);
	        int connectionCount = 0;
	        while (true) {
	            connectionCount++;
	            Socket socketConnection;
				socketConnection = server.accept();
				logger.info("New user connection: " + connectionCount);
				UserServerSocketHandler userServerSocketHandler = new UserServerSocketHandler(socketConnection, WorkerManager, connectionCount);
	            Thread handlerThread = new Thread(userServerSocketHandler);
	            handlerThread.start();
	            
	        }
	        // server.close();
		} catch (IOException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		}
		
	}
}
