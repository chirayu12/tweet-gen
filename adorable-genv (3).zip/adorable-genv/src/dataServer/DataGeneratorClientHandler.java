package dataServer;

import java.io.IOException;
import java.net.Socket;

import models.Tweet;
import models.Tweet.AirlineSentiments;
import utils.Logger;
import utils.SocketHandler;
import utils.Logger.InitiatorType;
import utils.Serializer;

public class DataGeneratorClientHandler extends SocketHandler {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);
	private WorkerManager WorkerManager;
	public DataGeneratorClientHandler(Socket connection, WorkerManager workerManager) {
        super(connection);
        WorkerManager = workerManager;
    }
	
	void beginReadStream() {
		String message = readLine();
		// logger.info("Received from Tweet Generator: " + message);
		Tweet tweet = parseMessageAsTweet(message);
		WorkerManager.storeTweet(tweet);
		try {
			String tweetToString = Serializer.toString(tweet);
			Tweet tweetFromString = Serializer.fromString(tweetToString);
			// logger.info("Number of Workers: " + WorkerManager.countWorkers());
			// logger.info("Serialized Tweet: " + tweetFromString.Tweet);
		} catch (IOException | ClassNotFoundException exception) {
			exception.printStackTrace();
			logger.error(exception.getMessage());
		}
		// Push to Guy talking to worker
		beginReadStream();
	}
	
	Tweet parseMessageAsTweet(String message) {
		Tweet tweet = new Tweet();
		try {
			String[] splitMessage = message.split("\t");
			long tweetId = Long.parseLong(splitMessage[0]);
			AirlineSentiments tweetAirlineSentiment = AirlineSentiments.valueOf(splitMessage[1]);
			String tweetAirline = splitMessage[5];
			String tweetText = splitMessage[10];
			String tweetDate = splitMessage[12];
			tweet = new Tweet(tweetId, tweetAirlineSentiment, tweetAirline, tweetText, tweetDate);
			
		} catch(Exception exception) {
			logger.error(exception.getMessage());
		}
		return tweet;
	}
}
