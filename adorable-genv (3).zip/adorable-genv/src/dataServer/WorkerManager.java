package dataServer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import models.IWorkerManagerEventListener;
import models.IWorkerServerEventListener;
import models.Query;
import models.Tweet;
import models.UserRequest;
import models.UserRequest.StatusType;
import models.UserServerQueryResponse;
import models.Worker;
import models.WorkerQueryResponse;
import models.WorkerServerRequest;
import models.WorkerServerRequest.RequestType;
import utils.Logger;
import utils.Logger.InitiatorType;

public class WorkerManager implements IWorkerServerEventListener {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);

	private IWorkerManagerEventListener Listener;
	public void setWorkerManagerListener(IWorkerManagerEventListener listener) {
		Listener = listener;
	}
	
	private LinkedHashMap<String, Worker> Workers = new LinkedHashMap<String, Worker>();
	private LinkedHashMap<String, UserRequest> UserRequests = new LinkedHashMap<String, UserRequest>();
	
	// THe ID of the current worker we are storing on
	private int CurrentStoreIndex = 0;
	final int MaxTweetsPerStore = 4000;
	
	public void createInstance() {
		logger.info("Creating A New Instance of a Worker!!!!!!!!!!!!!!!!");
	}
	public int countWorkers() {
		return Workers.size();
	}
	
	public boolean initialize() {
		// Start the initial 2 workers that run
		createInstance();
		createInstance();
		return true;
	}
	
	public void storeTweet(Tweet tweet) {
		Object[] workersKeySet = Workers.keySet().toArray();
		
		if(workersKeySet.length <= CurrentStoreIndex) {
			logger.error("Store unavailable");
			return;
		}
		
		String currentStoreWorkerId = (String) workersKeySet[CurrentStoreIndex];
		Worker currentStoreWorker = Workers.get(currentStoreWorkerId);
		
		
		if(currentStoreWorker.TweetCount == 0) {
			// Do for first tweet store only
			if(workersKeySet.length - 1 <= CurrentStoreIndex) {
				// We are on the last worker, create a new one;
				logger.info("Last Worker, initiating create request");
				createInstance();
			}
			
			currentStoreWorker.TweetRangeStart = tweet.Id;
		} else if(currentStoreWorker.TweetCount == MaxTweetsPerStore) {
			currentStoreWorker.TweetRangeEnd = tweet.Id;
			
			// Move to the next worker
			CurrentStoreIndex++;
		}
		
		// Create the new tweet request and send to the current worker
		WorkerServerRequest request = createRequest(tweet);
		currentStoreWorker.Handler.sendRequest(request);

		currentStoreWorker.TweetCount++;
	}
	
	public void submitQuery(Query query) {
		UserRequest userRequest = new UserRequest(query);
		ArrayList<String> responsibleWorkerIds = getResponsibleWorkerIds(query);
		
		for(String responsibleWorkerId : responsibleWorkerIds) {
			if(Workers.containsKey(responsibleWorkerId)) {
				// Add the responsible worker Id to the UserRequest Store
				userRequest.WorkerJobs.put(responsibleWorkerId, new WorkerQueryResponse());
				// Assign the request to the worker 
				queueForProcessing(Workers.get(responsibleWorkerId), query);
			}
			
		}
		
		// Add the userRequest to our UserRequestStore
		UserRequests.put(query.RequestId, userRequest);
	}
	
	public void cancelRequest(String requestId) {
		if(!UserRequests.containsKey(requestId)) {
			// Invalid request Id
			return;
		}
		
		// Get the request and change the status to canceled
		UserRequest userRequest = UserRequests.get(requestId);
		userRequest.Status = StatusType.CANCELED;
		
		// Get the queues for the responsible workers and dequeue the queries
		for(Object responsibleWorkerIdObject: userRequest.WorkerJobs.keySet().toArray()) {
			String responsibleWorkerId = (String) responsibleWorkerIdObject;
			if(Workers.containsKey(responsibleWorkerId)) {
				Workers.get(responsibleWorkerId).removeFromQueue(requestId);
			}
		}
	}
	
	public UserServerQueryResponse getRequest(String requestId) {
		UserServerQueryResponse response = new UserServerQueryResponse();
		response.Status = models.UserServerQueryResponse.StatusType.INVALID;
		if(!UserRequests.containsKey(requestId)) {
			// Invalid request Id
			return response;
		}
		
		// Get the userRequest
		UserRequest userRequest = UserRequests.get(requestId);
		response.Query = userRequest.Query;
		
		// Check if it is cancelled
		if(userRequest.Status == StatusType.CANCELED) {
			response.Status = models.UserServerQueryResponse.StatusType.CANCELED;
			return response;
		}
		
		// Set the status to completed
		response.Status = models.UserServerQueryResponse.StatusType.COMPLETED;
		
		// Aggregate Results
		for(WorkerQueryResponse workerQueryResponse: userRequest.WorkerJobs.values()) {
			response.NumberResult += workerQueryResponse.NumberOfTweets;
			response.FrequentCharacterResult = workerQueryResponse.MostFrequentChar;
			response.TextResult = workerQueryResponse.TweetText;
			if(!workerQueryResponse.Completed) {
				// If one worker hasn't completed reset the status back to processing
				response.Status = models.UserServerQueryResponse.StatusType.PROCESSING;
			}
		}
		return response;
	}
	
	public ArrayList<String> getResponsibleWorkerIds(Query query) {
		ArrayList<String> workerIds = new ArrayList<String>();
		
		// Query must search across all tweets and workers
		if(query.Type == Query.QueryType.WORD_SEARCH || query.Type == Query.QueryType.AIRLINE_SEARCH) {
			logger.info("Worker Size: " + Workers.size());
			for(Object key : Workers.keySet().toArray()) {
				logger.info("Responsible worker ID: " + (String) key);
				workerIds.add((String) key);
			}
			logger.info("There are " + workerIds.size() + " responsible worker(s)");
			return workerIds;
		}
		
		// Query is for single ID, find the ID with the Ranges in the store
		for(Map.Entry<String, Worker> entry : Workers.entrySet()) {
			Worker worker = entry.getValue();
			if((worker.TweetRangeStart != 0 && query.SearchId >= worker.TweetRangeStart) && (worker.TweetRangeEnd == 0 || query.SearchId <= worker.TweetRangeEnd)) {
				workerIds.add(entry.getKey());
				logger.info("Responsible worker ID: " + entry.getKey());
			}
		}
		
		logger.info("There are " + workerIds.size() + " responsible worker(s)");
		return workerIds;
	}
	
	public WorkerServerRequest createRequest(Tweet tweet) {
		WorkerServerRequest request = new WorkerServerRequest(RequestType.NEW_TWEET);
		request.Tweet = tweet;
		return request;
	}
	
	public WorkerServerRequest createRequest(Query query) {
		WorkerServerRequest request = new WorkerServerRequest(RequestType.NEW_QUERY);
		request.Query = query;
		return request;
	}
	
	private void queueForProcessing(Worker worker, Query query) {
		worker.insertInQueue(query);
		logger.info("Query inserted in a worker that is: " + worker.Busy);
		processNextRequest(worker);
	}
	
	
	private void processNextRequest(Worker worker) {
		if(worker.Connected && !worker.Busy) {
			Query nextQuery = worker.getNextItemInQueue();
			if(nextQuery != null) {
				logger.info("Processing Next Query in Queue");
				worker.Busy = true;
				WorkerServerRequest request = createRequest(nextQuery);
				worker.Handler.sendRequest(request);
			}
		}
	}
	
	private void completedCurrentRequest(Worker worker) {
		worker.Busy = false;
		logger.info("Completed Request, worker busy status is now " + worker.Busy);
		processNextRequest(worker);
	}
	
	public void completeRequest(WorkerQueryResponse response) {
		if(!UserRequests.containsKey(response.RequestId)) {
			// Invalid Request
			logger.error("Invalid RequestID: " + response.RequestId);
			return;
		}
		
		// Get UserRequest
		UserRequest userRequest = UserRequests.get(response.RequestId);
		if(!userRequest.WorkerJobs.containsKey(response.WorkerId)) {
			// Invalid Worker
			logger.error("Invalid WorkerJobs WorkerID: " + response.WorkerId);
			return;
		}
		
		// Update WorkerJob
		userRequest.WorkerJobs.put(response.WorkerId, response);
		
		// Get Worker and allow processing of next request
		if(!Workers.containsKey(response.WorkerId)) {
			// Invalid Worker
			logger.error("Invalid WorkerId: " + response.WorkerId);
			return;
		}
		Worker worker = Workers.get(response.WorkerId);
		completedCurrentRequest(worker);
	}

	@Override
	public void onNewWorkerConnection(String workerId, WorkerServerSocketHandler handler) {
		logger.info("New Worker Event");
		Worker worker = new Worker(handler);
		handler.sendWelcome(workerId);
		handler.waitForAcknowledgment();
		Workers.put(workerId, worker);
		if(Workers.size() == 2) {
			if (Listener != null) Listener.onInitialWorkersReady();
		}
	}

	@Override
	public void onExistingWorkerReconnection(String workerId, WorkerServerSocketHandler handler) {
		if(!Workers.containsKey(workerId)) {
			logger.error("Closing connection due to invalid reconnection ID" + workerId);
			try {
				handler.closeConnection();
			} catch (IOException exception) {
				logger.error(exception.getMessage());
			}
			return;
		}
		// Acknowledge the reconnection
		handler.sendAcknowledgement();
		
		// Set the worker status to ready
		Workers.get(workerId).Handler = handler;
		Workers.get(workerId).Busy = false;
		Workers.get(workerId).Connected = true;
		
	}
}
