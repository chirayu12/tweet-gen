package dataServer;

import java.io.IOException;
import java.net.Socket;

import models.WorkerQueryResponse;
import utils.Logger;
import utils.Serializer;
import utils.SocketHandler;
import utils.Logger.InitiatorType;

public class WorkerServerSocketMessageListener implements Runnable {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);
	private WorkerServerSocketHandler Handler;
	private WorkerManager WorkerManager;
	
	public WorkerServerSocketMessageListener(WorkerServerSocketHandler handler, WorkerManager workerManager) {
		 Handler = handler;
	     WorkerManager = workerManager;
	}
	@Override
	public void run() {
		listen();
	}
	
	public void listen() {
		String responseString = Handler.readLine();
		try {
			WorkerQueryResponse response = Serializer.fromString(responseString);
			logger.info("Received response message for request: " + response.RequestId);
			WorkerManager.completeRequest(response);
		} catch (ClassNotFoundException | IOException exception) {
			logger.error("Could not serialize user request: " + exception.getMessage());
		}
		listen();
	}

}
