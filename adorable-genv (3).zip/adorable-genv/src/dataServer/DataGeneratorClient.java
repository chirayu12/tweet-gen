package dataServer;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import utils.Logger;
import utils.Logger.InitiatorType;

public class DataGeneratorClient implements Runnable {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);
	WorkerManager WorkerManager;
	String[] Args;
 	public DataGeneratorClient(String args[], WorkerManager workerManager) {
 		Args = args;
		WorkerManager = workerManager;
	}
	@Override
	public void run() {
		String hostname = "localhost";
		int port = 1111;
		logger.info("Connecting to the Data Generator Server");
		try {
			Socket connection = new Socket(Args[0], port);
			DataGeneratorClientHandler handler = new DataGeneratorClientHandler(connection, WorkerManager);
			// Start reading tweets sent from the Data Generator
			handler.beginReadStream();
		} catch (UnknownHostException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		} catch (IOException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		}
	}
}
