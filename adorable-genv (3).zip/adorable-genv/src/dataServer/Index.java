package dataServer;

public class Index {
	public static void main(String[] args) {
		// Create the Bootstrapper, sit down, have some coffee and let it work
		new Bootstrap(args);
		
	}
}
