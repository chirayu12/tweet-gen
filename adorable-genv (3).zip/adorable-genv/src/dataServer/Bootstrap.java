package dataServer;

import models.IWorkerManagerEventListener;
import utils.Logger;
import utils.Logger.InitiatorType;

public class Bootstrap implements IWorkerManagerEventListener {
	private static Logger logger = new Logger(InitiatorType.DATA_SERVER);
	private WorkerManager WorkerManager;
	private WorkerServer WorkerServer;
	private UserServer UserServer;
	private DataGeneratorClient DataGeneratorClient;
	String[] Args;

	public Bootstrap(String[] args) {
		// Bootstrap the DataServer/Main Node
		Args = args;
		logger.info("Bootstrapping Main Node");
		// Create the Worker Manager
		WorkerManager = new WorkerManager();
		// Create the Worker Server
		WorkerServer = new WorkerServer(WorkerManager);
		Thread workerServerThread = new Thread(WorkerServer);
		workerServerThread.start();
		logger.info("We passed the worker server creation");
		
		// Make the WorkerManager a listener to events on the WorkerServer
		WorkerServer.setWorkerServerEventListener(WorkerManager);
		// Listen to events on the WorkerManager so we know when initial workers are ready
		WorkerManager.setWorkerManagerListener(this);
		// Create and wait for the default workers to connect, bootstrapping continues after initial workers connect
		WorkerManager.initialize();
	}

	@Override
	public void onInitialWorkersReady() {
		// Initial workers ready, continue bootstrapping
		
		logger.info("Initial Workers Ready");
		// Start the client for the data stream generator
		DataGeneratorClient = new DataGeneratorClient(Args, WorkerManager);
		Thread dataGeneratorClientThread = new Thread(DataGeneratorClient);
		dataGeneratorClientThread.start();
		// Start the server for the users
		UserServer = new UserServer(WorkerManager);
		Thread userServerThread = new Thread(UserServer);
		userServerThread.start();
	}
	
}
