package models;

import java.io.Serializable;

public class WorkerServerRequest implements Serializable {
	public enum RequestType {
		NEW_TWEET,
		NEW_QUERY,
		WORKER_HEALTH
	}
	public RequestType Type;
	public Tweet Tweet;
	public Query Query;
	
	public WorkerServerRequest(RequestType type) {
		Type = type;
	}
}
