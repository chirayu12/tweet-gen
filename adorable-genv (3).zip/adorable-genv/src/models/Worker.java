package models;

import java.util.ArrayList;
import java.util.Iterator;

import dataServer.WorkerServerSocketHandler;

public class Worker {
	// Id may not be needed
	public int Id;
	public long TweetRangeStart = 0;
	public long TweetRangeEnd = 0;
	public int TweetCount = 0;
	public WorkerServerSocketHandler Handler;
	public boolean Busy = false;
	public boolean Connected = true;
	private ArrayList<Query> Queue = new ArrayList<Query>();
	
	public Worker(WorkerServerSocketHandler handler) {
		Handler = handler;
	}
	
	public void insertInQueue(Query query) {
		ArrayList<Query> queue = Queue;
		query.setPosition(queue.size());
		queue.add(query);
		queue.sort(new Query.QueryComparator());
		Queue = queue;
	}
	
	public void removeFromQueue(String requestId) {
		Iterator<Query> iterator = Queue.iterator();
		while(iterator.hasNext()) {
			Query query = iterator.next();
			if(query.RequestId.equals(requestId)) {
				iterator.remove();
			}
		}
	}
	
	public Query getNextItemInQueue() {
		if(Queue.size() < 1) {
			return null;
		}
		Query nextQuery = Queue.get(0);
		Queue.remove(0);
		return nextQuery;
	}
	
}
