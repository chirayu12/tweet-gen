package models;

import java.io.Serializable;

public class UserClientRequest implements Serializable {
	public enum RequestType {
		QUERY,
		QUERY_STATUS_CHECK,
		QUERY_CANCELLATION,
		WORKER_HEALTH_CHECK
	}
	
	public Query Query;
	public RequestType Type;
	public String RequestId;
	
	public UserClientRequest(RequestType type) {
		Type = type;
	}
	
	public UserClientRequest(Query query) {
		Type = RequestType.QUERY;
		Query = query;
	}
	
	public UserClientRequest(RequestType requestType, String requestId) {
		Type = requestType;
		RequestId = requestId;
	}
}
