package models;

public interface IWorkerManagerEventListener {
	void onInitialWorkersReady();
}
