package models;

import dataServer.WorkerServerSocketHandler;

public interface IWorkerServerEventListener {
	void onNewWorkerConnection(String workerId, WorkerServerSocketHandler handler);
	void onExistingWorkerReconnection(String workerId, WorkerServerSocketHandler handler);
}
