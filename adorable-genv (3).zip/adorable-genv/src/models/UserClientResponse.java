package models;

import java.io.Serializable;

import models.UserClientRequest.RequestType;

public class UserClientResponse implements Serializable {
	public RequestType Type;
	public String RequestId;
	public UserServerQueryResponse QueryResponse;

	public UserClientResponse() {

	}
	
	
	public UserClientResponse(RequestType type) {
		Type = type;
	}
	
	public UserClientResponse(String requestId) {
		Type = RequestType.QUERY;
	}
	
	public UserClientResponse(UserServerQueryResponse response) {
		Type = RequestType.QUERY_STATUS_CHECK;
		QueryResponse = response;
	}
}