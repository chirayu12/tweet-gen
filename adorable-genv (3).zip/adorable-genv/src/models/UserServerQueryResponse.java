package models;

import java.io.Serializable;

import models.UserRequest.StatusType;

public class UserServerQueryResponse implements Serializable {
	public enum StatusType {
		PROCESSING,
		COMPLETED,
		CANCELED,
		INVALID
	}
	public Query Query;
	public StatusType Status = StatusType.PROCESSING;
	public String TextResult;
	public int NumberResult;
	public char FrequentCharacterResult;
	
	public UserServerQueryResponse() {
	}
	public UserServerQueryResponse(Query query) {
		Query = query;
	}
}
