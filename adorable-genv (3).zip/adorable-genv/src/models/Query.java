package models;

import java.io.Serializable;
import java.util.Comparator;

public class Query implements Serializable {
	public enum QueryType {
		ID_SEARCH,
		WORD_SEARCH,
		AIRLINE_SEARCH,
		ID_FREQUENT_CHARACTER,
	}
	public String RequestId;
	public String SearchString;
	public long SearchId;
	public QueryType Type;
	public int Deadline;
	public int Position;
	
	public Query(QueryType type, int deadline) {
		Type = type;
		Deadline = deadline;
	}
	
	public Query(String requestId, QueryType type, int deadline) {
		Type = type;
		Deadline = deadline;
		RequestId = requestId;
	}
	
	public void setPosition(int position) {
		Position = position;
	}
	
	public static class QueryComparator implements Comparator<Query> {
		public int compare(Query query, Query nextQuery) {
			// Sort based on Deadline first
			if (query.Deadline > nextQuery.Deadline) {
				return 1;
			} else if (query.Deadline < nextQuery.Deadline) {
				return -1;
			}

			// Sort based on position
			if (query.Position > nextQuery.Position) {
				return 1;
			} else if (query.Position < nextQuery.Position) {
				return -1;
			}
			
			// Return 0 if they have same rank
			return 0;
		}
	}
	
}
