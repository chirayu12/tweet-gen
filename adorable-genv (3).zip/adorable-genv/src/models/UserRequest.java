package models;

import java.io.Serializable;
import java.util.HashMap;

public class UserRequest implements Serializable {
	public enum StatusType {
		PROCESSING,
		COMPLETED,
		CANCELED
	}
	public Query Query;
	public StatusType Status = StatusType.PROCESSING;
	public HashMap<String, WorkerQueryResponse> WorkerJobs = new HashMap<String, WorkerQueryResponse>();
	
	public UserRequest(Query query) {
		Query = query;
	}
}
