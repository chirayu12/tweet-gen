package models;

import java.io.Serializable;
import java.time.LocalDate;

import models.Query.QueryType;

public class WorkerQueryResponse implements Serializable {
	public String WorkerId;
	public String RequestId;
	public int NumberOfTweets = 0;
	public char MostFrequentChar;
	public String TweetText;
	public LocalDate StartDate;
	public LocalDate EndDate;
	public boolean Completed = false;
	
	public WorkerQueryResponse(String workerId, String requestId) {
		WorkerId = workerId;
		RequestId = requestId;
	}
	
	public WorkerQueryResponse() {
		
	}
}
