package models;

import java.io.Serializable;

public class Tweet implements Serializable {
	public enum AirlineSentiments {
		negative,
		neutral,
		positive
	} 
	public long Id;
	public AirlineSentiments AirlineSentiment;
	public String Airline;
	public String Tweet;
	public String Date;
	
	public Tweet() {
		
	}
	
	public Tweet(long id, AirlineSentiments airlineSentiment, String airline, String text, String date) {
		Id = id;
		AirlineSentiment = airlineSentiment;
		Airline = airline;
		Tweet = text;
		Date = date;
	}
}
