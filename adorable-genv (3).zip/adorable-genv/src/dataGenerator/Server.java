package dataGenerator;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import utils.Logger;
import utils.Logger.InitiatorType;

public class Server {
	
	public static Logger logger = new Logger(InitiatorType.DATA_GENERATOR);

	public static void main(String[] args) {
		int port = 1111;
		String dataFile = args[0];
		int writeInterval = 1000;
		try {
			ServerSocket server = new ServerSocket(port);
			logger.info("Starting Server at " + port);
			Socket socketConnection = server.accept();
			logger.info("Established Connection");
			
			DataOutputStream out=new DataOutputStream(socketConnection.getOutputStream());  
	    	
			// Read the data file and write it to the socket every second
	        String line = "";
	        String split = "\t";
	        int counter = 0;
	        BufferedReader br = new BufferedReader(new FileReader(dataFile));

            while ((line = br.readLine()) != null) {
	        	if(counter>0) out.writeBytes(line + "\n");
	        	logger.info("Generated Tweet: " + line);
	            counter++;
	            Thread.sleep(writeInterval);
	            out.flush();      
            }
            socketConnection.close();
            server.close();
			
		} catch (IOException | InterruptedException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		}
		
	}

}
