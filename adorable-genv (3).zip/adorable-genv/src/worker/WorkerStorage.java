package worker;

import java.util.HashMap;

import models.Tweet;

public class WorkerStorage {
	private static WorkerStorage initialized = null;

    protected WorkerStorage(){

    }

    public static WorkerStorage getStorage(){
        if(initialized == null){
            initialized = new WorkerStorage();
        }
        return initialized;
    }
    
    public HashMap<Long, Tweet> Tweets = new HashMap<Long, Tweet>();
}
