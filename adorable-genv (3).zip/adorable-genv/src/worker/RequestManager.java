package worker;

import java.io.IOException;

import models.Query.QueryType;
import models.Tweet;
import models.WorkerQueryResponse;
import models.WorkerServerRequest;
import models.WorkerServerRequest.RequestType;
import utils.FrequentCharacterFinder;
import utils.Logger;
import utils.Serializer;
import utils.Logger.InitiatorType;

public class RequestManager implements Runnable {
	private static Logger logger = new Logger(InitiatorType.WORKER);
	private ClientHandler Handler;
	private WorkerServerRequest Request;
	
	public RequestManager(ClientHandler clientHandler, WorkerServerRequest request) {
		Handler = clientHandler;
		Request = request;
	}

	@Override
	public void run() {
		if(Request.Type == RequestType.NEW_TWEET) {
			storeTweet();
		} else if(Request.Type == RequestType.NEW_QUERY) {
			processQuery();
		} else if(Request.Type == RequestType.WORKER_HEALTH) {
			runHealthCheck();
		} 
	}
	
	public void storeTweet() {
		WorkerStorage storage = (WorkerStorage) WorkerStorage.getStorage();	
		storage.Tweets.put(Request.Tweet.Id, Request.Tweet);
	}
	
	public void processQuery() {
		WorkerQueryResponse response = new WorkerQueryResponse(Handler.AssignedId, Request.Query.RequestId);
		WorkerStorage storage = WorkerStorage.getStorage();	
		logger.info("Query Request - " + Request.Type);
		if(Request.Query.Type == QueryType.AIRLINE_SEARCH) {
			int sum = 0;
			for(Tweet tweet : storage.Tweets.values()) {
				if(tweet.Airline.equals(Request.Query.SearchString)) {
					sum++;
				}
			}
			response.NumberOfTweets = sum;
		} else if(Request.Query.Type == QueryType.WORD_SEARCH) {
			int sum = 0;
			for(Tweet tweet : storage.Tweets.values()) {
				if(tweet.Tweet.indexOf(Request.Query.SearchString) != -1) {
					sum++;
				}
			}
			response.NumberOfTweets = sum;
		}  else if(Request.Query.Type == QueryType.ID_SEARCH) {
			String text = null;
			if(storage.Tweets.containsKey(Request.Query.SearchId)) {
				text = storage.Tweets.get(Request.Query.SearchId).Tweet;
			}
			// Not found
			response.TweetText = text;
		} else if(Request.Query.Type == QueryType.ID_FREQUENT_CHARACTER) {
			char character = '0';
			if(storage.Tweets.containsKey(Request.Query.SearchId)) {
				character = FrequentCharacterFinder.Find(storage.Tweets.get(Request.Query.SearchId).Tweet);
			}
			response.MostFrequentChar = character;
		}
		
		try {
			response.Completed = true;
			String responseString = Serializer.toString(response);
			Handler.writeMessage(responseString);
		} catch (IOException exception) {
			logger.error("Could not serialize response: " + exception.getMessage());
			exception.printStackTrace();
		}
		
	}
	
	public void runHealthCheck() {
		
	}

}
