package worker;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import utils.Logger;
import utils.Logger.InitiatorType;

public class Client {
	private static Logger logger = new Logger(InitiatorType.WORKER);
	public static void main(String[] args) {
		String hostname = args[0];
		int port = 1112;
		logger.info("Connecting to the Worker Server");
		try {
			Socket connection = new Socket(hostname, port);
			ClientHandler handler = new ClientHandler(connection);
			// Start reading tweets sent from the Data Generator
			handler.register();
		} catch (UnknownHostException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		} catch (IOException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		}

	}

}
