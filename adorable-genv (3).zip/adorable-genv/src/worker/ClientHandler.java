package worker;

import java.io.IOException;
import java.net.Socket;

import models.WorkerServerRequest;
import utils.Logger;
import utils.Serializer;
import utils.SocketHandler;
import utils.Logger.InitiatorType;

public class ClientHandler extends SocketHandler {
	private static Logger logger = new Logger(InitiatorType.WORKER);
	public String AssignedId;
	public ClientHandler(Socket connection) {
        super(connection);
    }
	
	void register() {
		sendConnectionMessage();
		String acknowledgement = readLine();
		try {
			String[] acknowledgementData = acknowledgement.split("#");
			AssignedId = acknowledgementData[1];
			sendAcknowledgement();
			waitForRequests();
		} catch (Exception exception) {
			logger.error(exception.getMessage());
		}

	}
	
	public void waitForRequests() {
		String requestString = readLine();
		try {
			WorkerServerRequest request = Serializer.fromString(requestString);
			/*
			 * logger.info("New Request - " + request.Type); WorkerStorage storage =
			 * WorkerStorage.getStorage(); logger.info("Tweet Count - " +
			 * storage.Tweets.size());
			 */
			RequestManager requestManager = new RequestManager(this, request);
			Thread requestThread = new Thread(requestManager);
			requestThread.start();
			
		} catch (ClassNotFoundException | IOException exception) {
			logger.error("Could not deserialize request: " + exception.getMessage());
		}
		waitForRequests();
	}
	
	public void sendConnectionMessage() {
        writeMessage("NEWCONNECTION#");
    }
	
	public void sendReconnectionMessage(String assignedId) {
        writeMessage("EXISTINGCONNECTION#" + assignedId);
    }
}
