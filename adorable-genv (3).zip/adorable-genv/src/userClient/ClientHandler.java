package userClient;

import java.io.IOException;
import java.net.Socket;

import models.Query;
import models.Query.QueryType;
import models.UserClientRequest;
import models.UserClientRequest.RequestType;
import models.UserClientResponse;
import models.UserServerQueryResponse.StatusType;
import models.WorkerServerRequest;
import utils.Logger;
import utils.Serializer;
import utils.SocketHandler;
import utils.UserInput;
import utils.Logger.InitiatorType;

public class ClientHandler extends SocketHandler {
	private static Logger logger = new Logger(InitiatorType.WORKER);
	public String AssignedId;
	public ClientHandler(Socket connection) {
        super(connection);
    }
	
	public void waitForAcknowledgment() {
		String acknowledgement = readLine();
		try {
			String[] acknowledgementData = acknowledgement.split("#");
			AssignedId = acknowledgementData[1];
			System.out.println("---\nWelcome \nYour password is: " + AssignedId + "\n---");
			inputMenu();
		} catch (Exception exception) {
			logger.error(exception.getMessage());
		}
	}
	
	public void inputMenu() {
		System.out.println("Please choose from the options below to send your request in the format REQUEST_TYPE#PARAMETERS");
		System.out.println("1. Search for tweet text with ID - ID_SEARCH#TweetID#Deadline");
		System.out.println("2. Find the most frequent character in the tweet text with ID - FREQ_CHAR#TweetID#Deadline");
		System.out.println("3. Search for number of tweets containing the string - WORD_SEARCH#Keywords#Deadline");
		System.out.println("4. Search for number of tweets containing for the airline - AIRLINE_SEARCH#@Airline#Deadline");
		System.out.println("5. Get Result/Status of Query with request ID - STATUS#RequestId");
		System.out.println("6. Cancel Query with request ID - CANCEL#RequestId");
		System.out.println("7. Get health of workers - HEALTH#");
		System.out.println("8. Get health of workers - EXIT#");
		String userInput = UserInput.acceptLine();
		String[] menuInputData = userInput.split("#");
		
		if(menuInputData[0].equals("ID_SEARCH") && menuInputData.length == 3) {
			generateRequest(RequestType.QUERY, QueryType.ID_SEARCH, Long.parseLong(menuInputData[1]), Integer.parseInt(menuInputData[2]));
			receiveResponse();
		} else if(menuInputData[0].equals("FREQ_CHAR") && menuInputData.length == 3) {
			generateRequest(RequestType.QUERY, QueryType.ID_FREQUENT_CHARACTER, Long.parseLong(menuInputData[1]), Integer.parseInt(menuInputData[2]));
			receiveResponse();
		} else if(menuInputData[0].equals("WORD_SEARCH") && menuInputData.length == 3) {
			generateRequest(RequestType.QUERY, QueryType.WORD_SEARCH, menuInputData[1], Integer.parseInt(menuInputData[2]));
			receiveResponse();
		} else if(menuInputData[0].equals("AIRLINE_SEARCH") && menuInputData.length == 3) {
			generateRequest(RequestType.QUERY, QueryType.AIRLINE_SEARCH, menuInputData[1], Integer.parseInt(menuInputData[2]));
			receiveResponse();
		} else if(menuInputData[0].equals("STATUS") && menuInputData.length == 2) {
			generateRequest(RequestType.QUERY_STATUS_CHECK, menuInputData[1]);
			receiveResponse();
		} else if(menuInputData[0].equals("CANCEL") && menuInputData.length == 2) {
			generateRequest(RequestType.QUERY_CANCELLATION, menuInputData[1]);
			receiveResponse();
		} else if(menuInputData[0].equals("HEALTH") && menuInputData.length > 0) {
			generateRequest(RequestType.WORKER_HEALTH_CHECK);
			receiveResponse();
		} else if(menuInputData[0].equals("EXIT") && menuInputData.length > 0) {
			exit();
		} else {
			showInputError();
			inputMenu();
		}
		
		anyKeyForMenu();
	}
	
	public void sendRequest(UserClientRequest request) {
		try {
			String requestString = Serializer.toString(request);
			writeMessage(requestString);
		} catch (Exception exception) {
			logger.error("Could not serialize user request: " + exception.getMessage());
		}
	}
	
	public void receiveResponse() {
		String responseString = readLine();
		try {
			UserClientResponse response = Serializer.fromString(responseString);
			displayResponse(response);
		} catch (ClassNotFoundException | IOException exception) {
			logger.error("Exception serializing the server response: " + exception.getMessage());
		}
	}
	
	public void displayResponse(UserClientResponse response) {
		System.out.println("--------------------------------");
		System.out.println("Response for Request: " + response.Type);
		if(response.Type == RequestType.QUERY) {
			System.out.println("Your query has been submitted and is processing, use the ID below to get the status/response or cancel");
			System.out.println("Query ID: " + response.RequestId);
		} else if(response.Type == RequestType.QUERY_CANCELLATION) {
			System.out.println("Your query cancellation request has been submitted");
		} else if(response.Type == RequestType.QUERY_STATUS_CHECK) {
			if(response.QueryResponse.Status == StatusType.CANCELED) {
				System.out.println("This query has been cancelled");
			} else {
				System.out.println("Query Status: " + response.QueryResponse.Status);
				if(response.QueryResponse.Query.Type == QueryType.AIRLINE_SEARCH || response.QueryResponse.Query.Type == QueryType.WORD_SEARCH) {
					System.out.println("Number of Tweets: " + response.QueryResponse.NumberResult);
				} else if(response.QueryResponse.Query.Type == QueryType.ID_FREQUENT_CHARACTER) {
					System.out.println("Most Frequent Character: " + response.QueryResponse.FrequentCharacterResult);
				} else if(response.QueryResponse.Query.Type == QueryType.ID_SEARCH) {
					System.out.println("Tweet Text: " + response.QueryResponse.TextResult);
				}
			}
		} else if(response.Type == RequestType.WORKER_HEALTH_CHECK) {
			System.out.println("Healthy guy");
		}
		System.out.println("--------------------------------");
	}
	
	public void generateRequest(RequestType requestType, QueryType queryType, long searchId, int deadline) {
		UserClientRequest request = new UserClientRequest(requestType);
		Query query = new Query(queryType, deadline);
		query.SearchId = searchId;
		request.Query = query;
		sendRequest(request);
	}
	
	public void generateRequest(RequestType requestType, QueryType queryType, String searchString, int deadline) {
		UserClientRequest request = new UserClientRequest(requestType);
		Query query = new Query(queryType, deadline);
		query.SearchString = searchString;
		request.Query = query;
		sendRequest(request);
	}
	
	public void generateRequest(RequestType requestType, String requestId) {
		UserClientRequest request = new UserClientRequest(requestType, requestId);
		sendRequest(request);
	}
	
	public void generateRequest(RequestType requestType) {
		UserClientRequest request = new UserClientRequest(requestType);
		sendRequest(request);
	}
	
	public void anyKeyForMenu() {
		System.out.println("\n---\nPress any key to show menu\n---");
		UserInput.accept();
		inputMenu();
	}
	
	public void showInputError() {
		System.out.println("Invalid Input");
	}
	
	public void exit() {
		try {
			closeConnection();
			System.exit(0);
		} catch (Exception exception) {
			logger.error("Exception while closing connection: " + exception.getMessage());
		}
	}
}
