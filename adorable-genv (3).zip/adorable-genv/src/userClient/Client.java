package userClient;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import utils.Logger;
import utils.Logger.InitiatorType;

public class Client {
	private static Logger logger = new Logger(InitiatorType.USER_CLIENT);
	public static void main(String[] args) {
		String hostname = args[0];
		int port = 1113;
		logger.info("Connecting to the User Server");
		try {
			Socket connection = new Socket(hostname, port);
			ClientHandler handler = new ClientHandler(connection);
			// Wait for Server acknowledgment with user password
			handler.waitForAcknowledgment();
		} catch (UnknownHostException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		} catch (IOException exception) {
			logger.error(exception.getMessage());
			// exception.printStackTrace();
		}

	}

}
